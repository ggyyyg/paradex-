import pandas as pd
import numpy as np
from datetime import datetime
import csv
import glob
from wcwidth import wcswidth

# ============================================================================
# 配置 - 在这里添加你的 CSV 文件路径
# ============================================================================

# 设置为 True 合并所有 CSV，False 单独处理每个 CSV
COMBINE = False  # True 或 False

# 选项 1：列出特定文件
csv_files = [
    r'D:/main.csv',
    #r'D:/alt.csv',  # 取消注释并添加更多文件
    #r'D:/alt2.csv',
]

# 选项 2：使用 glob 模式读取目录下所有 CSV 文件
# csv_files = glob.glob(r'D:/trading_reports/*.csv')

# ============================================================================
# 表格显示配置 - 选择显示哪些表格
# ============================================================================

SHOW_TABLES = {
    'all': False,  # 设置为 True 显示所有表格（覆盖单独设置）
    
    # 单独表格控制（仅在 'all' 为 False 时使用）
    'daily_by_market': False,   # 每日市场汇总
    'overall_by_market': False, # 总体市场汇总
    'overall_daily': True,      # 每日总体汇总
    'grand_total': True,        # 总计
}

# ============================================================================

print("=" * 80)
print("正在读取 CSV 文件")
print("=" * 80)

# 读取单个 CSV 文件的函数
def read_csv_file(file_path):
    needed_columns = ['created_at', 'market', 'side', 'price', 'size', 'fee', 'realized_pnl']
    
    strategies = [
        ("standard", lambda: pd.read_csv(file_path, index_col=False, usecols=needed_columns)),
        ("quoted", lambda: pd.read_csv(file_path, index_col=False, quotechar='"', doublequote=True, usecols=needed_columns)),
        ("python", lambda: pd.read_csv(file_path, index_col=False, engine='python', usecols=needed_columns)),
        ("spaced", lambda: pd.read_csv(file_path, index_col=False, skipinitialspace=True, usecols=needed_columns)),
        ("full", lambda: pd.read_csv(file_path, index_col=False, quotechar='"', doublequote=True, skipinitialspace=True, engine='python', usecols=needed_columns)),
    ]
    
    df = None
    method = None
    
    for name, func in strategies:
        try:
            df = func()
            method = name
            break
        except Exception as e:
            continue
    
    # 如果所有方法都失败，逐行读取并跳过错误行
    if df is None:
        rows = []
        bad_lines = []
        
        with open(file_path, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader)
            
            # 获取所需列索引
            col_indices = [headers.index(col) for col in needed_columns]
            
            for i, row in enumerate(reader, start=2):
                if len(row) == len(headers):
                    filtered_row = [row[idx] for idx in col_indices]
                    rows.append(filtered_row)
                else:
                    bad_lines.append((i, len(row)))
                    if len(row) > len(headers):
                        fixed_row = row[:len(headers)-1] + [','.join(row[len(headers)-1:])]
                        filtered_row = [fixed_row[idx] for idx in col_indices]
                        rows.append(filtered_row)
        
        df = pd.DataFrame(rows, columns=needed_columns)
        method = f"手动修复 ({len(bad_lines)} 修复)" if bad_lines else "手动"
    
    return df, method

# 处理并显示 DataFrame 的函数
def process_and_display(df, title=""):
    if title:
        print("\n" + "=" * 80)
        print(title)
        print("=" * 80)
    
    # 转换数据类型
    df['price'] = pd.to_numeric(df['price'], errors='coerce')
    df['size'] = pd.to_numeric(df['size'], errors='coerce')
    df['fee'] = pd.to_numeric(df['fee'], errors='coerce')
    df['realized_pnl'] = pd.to_numeric(df['realized_pnl'], errors='coerce')

    # 删除关键字段为空的行
    initial_count = len(df)
    df = df.dropna(subset=['price', 'size'])
    removed = initial_count - len(df)

    # 转换 created_at 为 datetime
    df['created_at'] = pd.to_datetime(df['created_at'])
    df['date'] = df['created_at'].dt.date

    # 显示概览
    markets = df['market'].unique().tolist()
    print(f"行数        : {len(df):,}" + (f" （已移除 {removed} 行）" if removed > 0 else ""))
    print(f"时间范围    : {df['created_at'].min()} → {df['created_at'].max()}")
    print(f"市场数量({df['market'].nunique()}) : {', '.join(markets)}")

    # 计算每笔交易的成交额
    df['volume'] = df['price'] * df['size']

    # 创建买卖指标
    df['is_buy'] = (df['side'] == 'BUY').astype(int)
    df['is_sell'] = (df['side'] == 'SELL').astype(int)

    # 检查显示哪些表格
    show_all = SHOW_TABLES.get('all', True)
    
    # ========================================================================
    # 表格 1：每日市场汇总
    # ========================================================================
    def pad_string(s, width, align='left'):
        """Pad string s to display width width, accounting for wide chars."""
        s = str(s)
        pad_len = max(width - wcswidth(s), 0)
        if align == 'left':
            return s + ' ' * pad_len
        elif align == 'right':
            return ' ' * pad_len + s
        elif align == 'center':
            left = pad_len // 2
            right = pad_len - left
            return ' ' * left + s + ' ' * right
    
    if show_all or SHOW_TABLES.get('daily_by_market', False):
        summary = df.groupby(['date', 'market']).agg({
            'volume': 'sum',
            'fee': 'sum',
            'realized_pnl': 'sum',
            'is_buy': 'sum',
            'is_sell': 'sum'
        }).reset_index()

        summary = summary.rename(columns={'is_buy': 'buys', 'is_sell': 'sells'})
        summary['net_pnl'] = summary['realized_pnl'] - summary['fee']
        summary['fees/10k'] = (summary['net_pnl'] / summary['volume']) * 10000
        summary['trades'] = summary.apply(lambda row: f"{int(row['buys'] + row['sells'])} ({int(row['buys'])}/{int(row['sells'])})", axis=1)

        summary['volume'] = summary['volume'].round(2)
        summary['fee'] = summary['fee'].round(4)
        summary['realized_pnl'] = summary['realized_pnl'].round(4)
        summary['net_pnl'] = summary['net_pnl'].round(4)
        summary['fees/10k'] = summary['fees/10k'].round(4)
        summary = summary.sort_values(['date', 'market'])

        print("═" * 130)
        print("每日市场汇总")
        print("═" * 130)

        headers = ['日期', '市场', '成交额', '手续费', '已实现盈亏', '净盈亏', '万损', '交易次数 (买/卖)']
        widths = [12, 20, 12, 10, 12, 10, 10, 18]
        aligns = ['left','left','right','right','right','right','right','right']

        header_row = "   ".join([pad_string(h, w, a) for h, w, a in zip(headers, widths, aligns)])
        print(header_row)
        print("─" * 130)

        last_date = None
        for _, row in summary.iterrows():
            current_date = row['date']
            # 当日期变化时打印一行“·”
            if last_date is not None and current_date != last_date:
                print("·" * 130)
            date_str = str(current_date) if current_date != last_date else ""
            row_values = [
                date_str,
                row['market'],
                f"{row['volume']:,.2f}",
                f"{row['fee']:,.4f}",
                f"{row['realized_pnl']:,.4f}",
                f"{row['net_pnl']:,.4f}",
                f"{row['fees/10k']:,.4f}",
                row['trades']
            ]
            print("   ".join([pad_string(v, w, a) for v, w, a in zip(row_values, widths, aligns)]))
            last_date = current_date

        print("═" * 130)

    # ========================================================================
    # 表格 2：总体市场汇总
    # ========================================================================
    if show_all or SHOW_TABLES.get('overall_by_market', False):
        market_summary = df.groupby('market').agg({
            'volume': 'sum',
            'fee': 'sum',
            'realized_pnl': 'sum',
            'is_buy': 'sum',
            'is_sell': 'sum'
        }).reset_index()

        market_summary = market_summary.rename(columns={'is_buy': 'buys', 'is_sell': 'sells'})
        market_summary['net_pnl'] = market_summary['realized_pnl'] - market_summary['fee']
        market_summary['fees/10k'] = (market_summary['net_pnl'] / market_summary['volume']) * 10000
        market_summary['trades'] = market_summary.apply(lambda row: f"{int(row['buys'] + row['sells'])} ({int(row['buys'])}/{int(row['sells'])})", axis=1)

        market_summary['volume'] = market_summary['volume'].round(2)
        market_summary['fee'] = market_summary['fee'].round(4)
        market_summary['realized_pnl'] = market_summary['realized_pnl'].round(4)
        market_summary['net_pnl'] = market_summary['net_pnl'].round(4)
        market_summary['fees/10k'] = market_summary['fees/10k'].round(4)

        print("\n")
        print("═" * 110)
        print("总体市场汇总")
        print("═" * 110)

        headers = ['市场', '成交额', '手续费', '已实现盈亏', '净盈亏', '万损', '交易次数 (买/卖)']
        widths = [20, 12, 10, 12, 10, 10, 18]
        aligns = ['left','right','right','right','right','right','right']

        header_row = "   ".join([pad_string(h, w, a) for h, w, a in zip(headers, widths, aligns)])
        print(header_row)
        print("─" * 110)

        for _, row in market_summary.iterrows():
            row_values = [
                row['market'],
                f"{row['volume']:,.2f}",
                f"{row['fee']:,.4f}",
                f"{row['realized_pnl']:,.4f}",
                f"{row['net_pnl']:,.4f}",
                f"{row['fees/10k']:,.4f}",
                row['trades']
            ]
            print("   ".join([pad_string(v, w, a) for v, w, a in zip(row_values, widths, aligns)]))
        print("═" * 110)

    # ========================================================================
    # 表格 3：每日总体汇总
    # ========================================================================
    if show_all or SHOW_TABLES.get('overall_daily', False):
        daily_summary = df.groupby('date').agg({
            'volume': 'sum',
            'fee': 'sum',
            'realized_pnl': 'sum',
            'is_buy': 'sum',
            'is_sell': 'sum'
        }).reset_index()

        daily_summary = daily_summary.rename(columns={'is_buy': 'buys', 'is_sell': 'sells'})
        daily_summary['net_pnl'] = daily_summary['realized_pnl'] - daily_summary['fee']
        daily_summary['fees/10k'] = (daily_summary['net_pnl'] / daily_summary['volume']) * 10000
        daily_summary['trades'] = daily_summary.apply(lambda row: f"{int(row['buys'] + row['sells'])} ({int(row['buys'])}/{int(row['sells'])})", axis=1)

        daily_summary['volume'] = daily_summary['volume'].round(2)
        daily_summary['fee'] = daily_summary['fee'].round(4)
        daily_summary['realized_pnl'] = daily_summary['realized_pnl'].round(4)
        daily_summary['net_pnl'] = daily_summary['net_pnl'].round(4)
        daily_summary['fees/10k'] = daily_summary['fees/10k'].round(4)
        daily_summary = daily_summary.sort_values('date')

        print("\n")
        print("═" * 110)
        print("每日总体汇总")
        print("═" * 110)

        headers = ['日期', '成交额', '手续费', '已实现盈亏', '净盈亏', '万损', '交易次数 (买/卖)']
        widths = [12, 12, 10, 12, 10, 12, 18]
        aligns = ['left','right','right','right','right','right','right']

        header_row = "   ".join([pad_string(h, w, a) for h, w, a in zip(headers, widths, aligns)])
        print(header_row)
        print("─" * 110)

        for _, row in daily_summary.iterrows():
            row_values = [
                str(row['date']),
                f"{row['volume']:,.2f}",
                f"{row['fee']:,.4f}",
                f"{row['realized_pnl']:,.4f}",
                f"{row['net_pnl']:,.4f}",
                f"{row['fees/10k']:,.4f}",
                row['trades']
            ]
            print("   ".join([pad_string(v, w, a) for v, w, a in zip(row_values, widths, aligns)]))
        print("═" * 110)

    # ========================================================================
    # 表格 4：总计
    # ========================================================================
    if show_all or SHOW_TABLES.get('grand_total', False):
        total_volume = df['volume'].sum()
        total_fees = df['fee'].sum()
        total_realized_pnl = df['realized_pnl'].sum()
        total_net_pnl = total_realized_pnl - total_fees
        total_fees_per_10k = (total_net_pnl / total_volume) * 10000
        total_buys = df['is_buy'].sum()
        total_sells = df['is_sell'].sum()
        total_trades = total_buys + total_sells
        trades_str = f"{int(total_trades)} ({int(total_buys)}/{int(total_sells)})"

        print("\n")
        print("═" * 60)
        print("总计")
        print("═" * 60)

        print(f"{pad_string('总成交额:',25,'left')}{pad_string(f'{total_volume:,.2f}',30,'right')}")
        print(f"{pad_string('总手续费:',25,'left')}{pad_string(f'{total_fees:,.4f}',30,'right')}")
        print(f"{pad_string('总已实现盈亏:',25,'left')}{pad_string(f'{total_realized_pnl:,.4f}',30,'right')}")
        print(f"{pad_string('总净盈亏:',25,'left')}{pad_string(f'{total_net_pnl:,.4f}',30,'right')}")
        print(f"{pad_string('万损:',25,'left')}{pad_string(f'{total_fees_per_10k:,.4f}',30,'right')}")
        print(f"{pad_string('总交易次数:',25,'left')}{pad_string(trades_str,30,'right')}")
        print("═" * 60)

# 读取所有 CSV 文件
all_dfs = []
file_data = []  # 存储元组 (文件路径, dataframe)

print(f"\n正在加载 {len(csv_files)} 个文件...")
print("─" * 80)

for i, file_path in enumerate(csv_files, 1):
    try:
        import os
        file_name = os.path.basename(file_path)
        df_temp, method = read_csv_file(file_path)
        
        if df_temp is not None:
            all_dfs.append(df_temp)
            file_data.append((file_path, df_temp))
            print(f"[{i}/{len(csv_files)}] {file_name:<25} → {len(df_temp):>8,} 行 ({method})")
    except Exception as e:
        print(f"[{i}/{len(csv_files)}] {file_name:<25} → 错误: {e}")

print("─" * 80)

if not all_dfs:
    print("✗ 没有文件可以成功读取！")
    exit(1)

# 根据 COMBINE 设置处理
if COMBINE:
    df = pd.concat(all_dfs, ignore_index=True)
    print(f"✓ 已合并 {len(file_data)} 个文件 → 共 {len(df):,} 行\n")
    process_and_display(df, "合并分析 - 所有 CSV 文件")
else:
    print(f"✓ 单独处理 {len(file_data)} 个文件...")
    for i, (file_path, df) in enumerate(file_data, 1):
        import os
        file_name = os.path.basename(file_path)
        process_and_display(df.copy(), f"文件 {i}/{len(file_data)}: {file_name}")
